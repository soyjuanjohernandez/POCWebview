package com.example.android.basicpermissions.webview

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.android.basicpermissions.R

class WebViewActivity : AppCompatActivity() {

    // Instancia de WebView.
    private lateinit var webview: WebView

    private val permission = arrayOf(Manifest.permission.CAMERA
            //,Manifest.permission.RECORD_AUDIO,
            //Manifest.permission.MODIFY_AUDIO_SETTINGS
    )
    private val requestCode = 1


    /**
     * Evento llamado al momento de abrir por primera vez la WebView.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        establecerParametrosWebView()
    }


    /**
     * Evento llamado al momento en que abandonamos y regresamos a la WebView.
     */
    override fun onResume() {
        super.onResume()

        establecerParametrosWebView()
    }


    /**
     * Realiza las configuraciones necesarias para la apertura del código QR en la WebView,
     * y sus permisos respectivos.
     */
    private fun establecerParametrosWebView() {
        setContentView(R.layout.activity_web_view)
        webview = findViewById(R.id.webview)

        val action: String? = intent?.action
        val data: Uri? = intent?.data


        WebViewSetup()
        if (!isPermissionGranted()) {

            askPermissions()

        }

        webview.webChromeClient = object : WebChromeClient() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
        }
    }


    private fun askPermissions() {
        ActivityCompat.requestPermissions(this, permission, requestCode)
    }

    private fun isPermissionGranted(): Boolean {
        permission.forEach {
            if (ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED)
                return false
        }

        return true
    }


    @SuppressLint("SetJavaScriptEnabled")
    private fun WebViewSetup() {

        val url = intent.extras!!.getString("url")
        webview.webChromeClient = WebChromeClient()


        webview.apply {
            if (url != null) {
                loadUrl(url)
            }

            Log.d("callBtn", "Url ::  $url!!!! ")
            /** Habilitar ejecuci&oacute;n de c&oacute;digo JavaScript. */
            settings.javaScriptEnabled = true
            /** Habilitar que JS abra ventanas autom&aacute;ticamente. */
            settings.javaScriptCanOpenWindowsAutomatically = true
            /** Habilitar el API de DOM Storage. */
            settings.domStorageEnabled = true
            /** Permite el acceso a contenidos de la URL. */
            settings.allowContentAccess = true
            //settings.safeBrowsingEnabled = true
            /** Requiere del usuario para reproducir multimedia? */
            settings.mediaPlaybackRequiresUserGesture = false
        }
    }

}